import { useEffect } from "react";
import useConversation from "../../zustand/useConversation";
import MessageInput from "./MessageInput";
import Messages from "./Messages";
import { TiMessages} from "react-icons/ti";
import { userAuthContext } from "../../context/AuthContext";
// import { useAuthContext } from "../../context/AuthContext";

const MessageContainer = () => {
	const {selectedConversation, setSelectedConversation} = useConversation();

	useEffect(() => {
		//cleaup function
		return () => setSelectedConversation(null)
	},[setSelectedConversation]);

  return (
    <div className="md:min-w-[450px] flex flex-col h-full">
		{!selectedConversation ? ( <NoChatSelected />
		) : (
    	<>
          {/* header */}
			<div className='bg-slate-200 px-4 py-2 mb-2'>
    					<span className='label-text'>To:</span> {" "}
						<span className='text-white-900 font-bold'>{selectedConversation.fullName}</span>
			</div>
			<Messages />
			<MessageInput />
			</>
		)}
            </div>
  )
};

export default MessageContainer;

const NoChatSelected = () => {
	const { authUser } = userAuthContext();
	return (
		<div className='flex items-center justify-center w-full h-full'>
			<div className='px-4 text-center sm:text-lg md:text-xl text-gray-200 font-semibold flex flex-col items-center gap-2'>
				<p>Welcome 👋 {authUser.fullName} ❄</p>
				<p>Select a chat to start messaging</p>
				<TiMessages className='text-3xl md:text-6xl text-center' />
			</div>
		</div>
	);
}


//starter code
// import MessageInput from "./MessageInput";
// import Messages from "./Messages";
// import { TiMessages} from "react-icons/ti"

// const MessageContainer = () => {
// 	const noChatSelected = true;
//   return (
//     <div className="md:min-w-[450px] flex flex-col">
// 		{noChatSelected ? ( <NoChatSelected />
// 		) : (
//     	<>
//           {/* header */}
// 			<div className='bg-slate-200 px-4 py-2 mb-2'>
//     					<span className='label-text'>To:</span> 
// 						<span className='text-white-900 font-bold'>John doe</span>
// 				</div>
    
// 			<Messages />
// 			<MessageInput />
// 			</>
// 		)}
//             </div>
//   )
// }

// export default MessageContainer;

// const NoChatSelected = () => {
// 	return (
// 		<div className='flex items-center justify-center w-full h-full'>
// 			<div className='px-4 text-center sm:text-lg md:text-xl text-gray-200 font-semibold flex flex-col items-center gap-2'>
// 				<p>Welcome 👋 Jones doe ❄</p>
// 				<p>Select a chat to start messaging</p>
// 				<TiMessages className='text-3xl md:text-6xl text-center' />
// 			</div>
// 		</div>
// 	);
// }



